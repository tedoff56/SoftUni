﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=TEDOFF\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}