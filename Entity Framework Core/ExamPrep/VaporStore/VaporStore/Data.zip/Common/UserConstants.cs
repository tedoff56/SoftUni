﻿namespace VaporStore.Common
{
    public static class UserConstants
    {
        public const int USER_USERNAME_MAX_LENGTH = 20;
        
        public const int USER_AGE_MAX_VALUE = 103;
    }
}