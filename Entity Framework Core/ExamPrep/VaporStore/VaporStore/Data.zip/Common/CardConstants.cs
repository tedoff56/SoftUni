﻿namespace VaporStore.Common
{
    public static class CardConstants
    {
        public const int CARD_CVC_MAX_LENGTH = 3;
    }
}