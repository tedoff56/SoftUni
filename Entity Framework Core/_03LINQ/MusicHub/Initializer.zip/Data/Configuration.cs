﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=TEDOFF\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
