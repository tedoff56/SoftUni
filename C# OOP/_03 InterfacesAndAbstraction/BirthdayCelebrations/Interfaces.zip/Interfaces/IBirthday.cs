﻿namespace BirthdayCelebrations.Interfaces
{
    public interface IBirthday
    {
        public string BirthDay { get; }
    }
}