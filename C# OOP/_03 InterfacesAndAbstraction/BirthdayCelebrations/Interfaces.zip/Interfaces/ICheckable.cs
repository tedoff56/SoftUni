﻿namespace BirthdayCelebrations.Interfaces
{
    public interface ICheckable
    {
        public string Id { get; }
        
    }
}