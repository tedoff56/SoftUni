﻿namespace MilitaryElite.Enumerations
{
    public enum StateEnum
    {
        inProgress,
        Finished
    }
}