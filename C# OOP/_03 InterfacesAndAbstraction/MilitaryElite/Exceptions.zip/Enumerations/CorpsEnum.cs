﻿namespace MilitaryElite.Enumerations
{
    public enum CorpsEnum
    {
        Airforces,
        Marines
    }
}